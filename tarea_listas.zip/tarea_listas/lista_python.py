# =====================================================================
#  lista_python.py  —  LISTA 2: con el list de PYTHON (built-in)
# ---------------------------------------------------------------------
#  Mismas operaciones que la Lista 1, pero ahora usamos lo que Python
#  ya trae: append, insert, pop, remove, sort, reverse, copy, len,
#  enumerate, next, bisect ... y LIST COMPREHENSIONS.
#
#      self.pasajeros -> [Pasajero, Pasajero, ...]   (crece sola)
#
#  ✅ OBLIGATORIO usar comprensiones de listas en (mínimo):
#       buscar · buscar_binaria · eliminar_por_valor (versión 2)
#       filtrar_mayores_de_edad · nombres_en_mayusculas
#
#  Recordatorio de la sintaxis:
#       [EXPRESIÓN for ELEMENTO in LISTA]            -> transformar
#       [ELEMENTO  for ELEMENTO in LISTA if COND]    -> filtrar
#       [EXPRESIÓN for ELEMENTO in LISTA if COND]    -> las dos a la vez
#
#  📌 Compara cada método con su gemelo de lista_manual.py:
#     allá eran 10 líneas, aquí casi siempre son 1 o 2.
#  Cuando termines un método, BORRA la línea "pass".
# =====================================================================

from bisect import bisect_left
from pasajero import Pasajero


class ListaPasajerosPython:

    def __init__(self):
        self.pasajeros = []               # list de Python: crece sola

    # -----------------------------------------------------------------
    # 1. AÑADIR  ✅ YA RESUELTO
    # -----------------------------------------------------------------
    def añadir(self, pasajero):
        """Añade al final con append()."""
        # ✅ MEJORA aplicada: la cédula es la clave, no se permite repetirla
        if self.buscar(pasajero.cedula) != -1:
            print("⚠ Ya existe un pasajero con esa cédula")
            return False
        self.pasajeros.append(pasajero)
        return True

    # -----------------------------------------------------------------
    # 2. LISTAR  ✅ YA RESUELTO
    # -----------------------------------------------------------------
    def listar(self):
        """Muestra los pasajeros con su posición usando enumerate()."""
        if not self.pasajeros:                  # lista vacía es False
            print("(lista vacía)")
            return
        for i, p in enumerate(self.pasajeros):
            print(f"[{i}] {p}")

    # -----------------------------------------------------------------
    # 3. LONGITUD
    # -----------------------------------------------------------------
    def longitud(self):
        """
        USA      : len()
        RETORNA  : int.   PRUEBA: datos de prueba -> 5
        """
        # Lista 1: 1 línea | Lista 2: 1 línea
        return len(self.pasajeros)

    # -----------------------------------------------------------------
    # 4. INSERTAR
    # -----------------------------------------------------------------
    def insertar(self, posicion, pasajero):
        """
        USA      : self.pasajeros.insert(posicion, pasajero)
        VALIDA   : 0 <= posicion <= len(self.pasajeros); si no, mensaje y False.
        PIENSA   : ¿por qué ya no tienes que correr nada a la derecha?
                   (Python lo hace por ti... pero lo sigue haciendo: O(n)).
        """
        # Lista 1: 16 líneas | Lista 2: 8 líneas
        if posicion < 0 or posicion > len(self.pasajeros):
            print("⚠ Posición no válida")
            return False
        if self.buscar(pasajero.cedula) != -1:
            print("⚠ Ya existe un pasajero con esa cédula")
            return False
        self.pasajeros.insert(posicion, pasajero)
        return True
        # 🔎 RESPUESTA (Fase 3): insert parece "gratis", pero Python SÍ corre
        #    los elementos a la derecha por dentro (lo hace en C, mucho más
        #    rápido que mi while, pero lo hace). Por eso insert(pos) es O(n):
        #    cuantos más elementos haya después de 'pos', más trabajo. En
        #    cambio append es O(1) amortizado: solo escribe al final.

    # -----------------------------------------------------------------
    # 5. BUSCAR POR CÉDULA  (con COMPRENSIÓN)
    # -----------------------------------------------------------------
    def buscar(self, cedula):
        """
        RETORNA  : la posición (int) o -1.
        USA      : una comprensión con enumerate que junte las posiciones
                   que coinciden:
                       posiciones = [i for i, p in enumerate(self.pasajeros)
                                     if p.cedula == cedula]
                   Si la lista 'posiciones' está vacía -> -1,
                   si no -> posiciones[0].
        EXTRA    : investiga la versión con next(...):
                   next((i for i, p in enumerate(...) if ...), -1)
        PRUEBA   : buscar("0987654321") -> 2 ;  buscar("1111111111") -> -1
        """
        # Lista 1: 4 líneas | Lista 2: 3 líneas
        posiciones = [i for i, p in enumerate(self.pasajeros)
                      if p.cedula == cedula]
        return posiciones[0] if posiciones else -1
        # EXTRA (versión con next, se detiene en la primera coincidencia):
        # return next((i for i, p in enumerate(self.pasajeros)
        #              if p.cedula == cedula), -1)

    # -----------------------------------------------------------------
    # 6. BUSCAR BINARIA  (con COMPRENSIÓN + bisect)
    # -----------------------------------------------------------------
    def buscar_binaria(self, cedula):
        """
        ⚠ REQUISITO: lista ordenada por cédula (ordenar_asc antes).
        PASOS    :
          1. cedulas = [p.cedula for p in self.pasajeros]   # COMPRENSIÓN
          2. i = bisect_left(cedulas, cedula)   # dónde "debería" estar
          3. Si i < len(cedulas) y cedulas[i] == cedula -> return i
          4. return -1
        PRUEBA   : datos ordenados -> buscar_binaria("0923456789") -> 2
        """
        # Lista 1: 11 líneas | Lista 2: 5 líneas
        cedulas = [p.cedula for p in self.pasajeros]    # COMPRENSIÓN
        i = bisect_left(cedulas, cedula)    # dónde "debería" estar
        if i < len(cedulas) and cedulas[i] == cedula:
            return i
        return -1

    # -----------------------------------------------------------------
    # 7. MODIFICAR
    # -----------------------------------------------------------------
    def modificar(self, cedula, nuevo_nombre, nueva_edad):
        """
        PASOS    : pos = self.buscar(cedula); si -1 -> False;
                   si no, cambia self.pasajeros[pos].nombre y .edad -> True
        """
        # Lista 1: 7 líneas | Lista 2: 7 líneas
        pos = self.buscar(cedula)
        if pos == -1:
            print("⚠ No existe un pasajero con esa cédula")
            return False
        self.pasajeros[pos].nombre = nuevo_nombre
        self.pasajeros[pos].edad = nueva_edad
        return True

    # -----------------------------------------------------------------
    # 8. ELIMINAR POR POSICIÓN
    # -----------------------------------------------------------------
    def eliminar_por_posicion(self, posicion):
        """
        USA      : self.pasajeros.pop(posicion)   (retorna el eliminado)
        VALIDA   : 0 <= posicion < len(...); si no -> mensaje y None
        """
        # Lista 1: 9 líneas | Lista 2: 4 líneas
        if posicion < 0 or posicion >= len(self.pasajeros):
            print("⚠ Posición no válida")
            return None
        return self.pasajeros.pop(posicion)

    # -----------------------------------------------------------------
    # 9. ELIMINAR POR VALOR (por cédula)  — hazlo de DOS formas
    # -----------------------------------------------------------------
    def eliminar_por_valor(self, cedula):
        """
        FORMA 1 (remove):
            pos = self.buscar(cedula) ... self.pasajeros.remove(self.pasajeros[pos])
        FORMA 2 (COMPRENSIÓN) — la que debe quedar activa:
            antes = len(self.pasajeros)
            self.pasajeros = [p for p in self.pasajeros if p.cedula != cedula]
            return len(self.pasajeros) < antes      # True si eliminó algo
        Deja la FORMA 1 comentada para comparar.
        """
        # Lista 1: 6 líneas | Lista 2: 6 líneas
        # FORMA 1 (remove) — comentada para comparar:
        # pos = self.buscar(cedula)
        # if pos == -1:
        #     print("⚠ No existe un pasajero con esa cédula")
        #     return False
        # self.pasajeros.remove(self.pasajeros[pos])
        # return True

        # FORMA 2 (COMPRENSIÓN) — la que queda activa:
        antes = len(self.pasajeros)
        self.pasajeros = [p for p in self.pasajeros if p.cedula != cedula]
        if len(self.pasajeros) < antes:         # True si eliminó algo
            return True
        print("⚠ No existe un pasajero con esa cédula")
        return False

    # -----------------------------------------------------------------
    # 10. ORDENAR ASCENDENTE (por cédula)
    # -----------------------------------------------------------------
    def ordenar_asc(self):
        """
        USA      : self.pasajeros.sort(key=lambda p: p.cedula)
        PIENSA   : ¿qué hace key=? ¿qué pasaría sin él? (pruébalo)
        """
        # Lista 1: 7 líneas | Lista 2: 1 línea
        self.pasajeros.sort(key=lambda p: p.cedula)
        # 🔎 RESPUESTA (Fase 3): key= le dice a sort() QUÉ dato de cada
        #    pasajero debe comparar (aquí la cédula). Sin key, Python intenta
        #    comparar dos objetos Pasajero entre sí y no sabe hacerlo:
        #        TypeError: '<' not supported between instances of
        #        'Pasajero' and 'Pasajero'

    # -----------------------------------------------------------------
    # 11. ORDENAR DESCENDENTE (por cédula)
    # -----------------------------------------------------------------
    def ordenar_desc(self):
        """ USA : sort(key=..., reverse=True) """
        # Lista 1: 7 líneas | Lista 2: 1 línea
        self.pasajeros.sort(key=lambda p: p.cedula, reverse=True)

    # -----------------------------------------------------------------
    # 12. REVERSAR
    # -----------------------------------------------------------------
    def reversar(self):
        """ USA : self.pasajeros.reverse()   (no es lo mismo que ordenar_desc) """
        # Lista 1: 8 líneas | Lista 2: 1 línea
        self.pasajeros.reverse()    # invierte el orden actual (NO ordena)

    # -----------------------------------------------------------------
    # 13. COPIAR
    # -----------------------------------------------------------------
    def copiar(self):
        """
        PASOS    :
          nueva = ListaPasajerosPython()
          nueva.pasajeros = self.pasajeros.copy()    # o self.pasajeros[:]
          return nueva
        ⚠ OJO    : es una copia SUPERFICIAL: las dos listas son distintas,
                   pero los objetos Pasajero de adentro son los MISMOS.
                   Reversar la copia no afecta al original;
                   modificar un pasajero de la copia... ¡sí! Pruébalo.
        """
        # Lista 1: 4 líneas | Lista 2: 3 líneas
        nueva = ListaPasajerosPython()
        nueva.pasajeros = self.pasajeros.copy()    # o self.pasajeros[:]
        return nueva
        # 🔎 RESPUESTA (Fase 3): al reversar la copia, el original queda
        #    intacto porque son DOS listas distintas. Pero si modifico un
        #    pasajero de la copia (copia.modificar(...)), el original TAMBIÉN
        #    cambia: copy() es SUPERFICIAL, copia la lista pero no los
        #    objetos Pasajero de adentro; ambas listas apuntan a los MISMOS
        #    objetos. Para duplicarlos habría que usar copy.deepcopy().

    # -----------------------------------------------------------------
    # 14. FILTRAR MAYORES DE EDAD  (COMPRENSIÓN que FILTRA)
    # -----------------------------------------------------------------
    def filtrar_mayores_de_edad(self):
        """
        RETORNA  : una NUEVA ListaPasajerosPython.
        PASOS    :
          nueva = ListaPasajerosPython()
          nueva.pasajeros = [p for p in self.pasajeros if p.es_mayor_de_edad()]
          return nueva
        PRUEBA   : datos de prueba -> todos menos Beto
        """
        # Lista 1: 5 líneas | Lista 2: 3 líneas
        nueva = ListaPasajerosPython()
        nueva.pasajeros = [p for p in self.pasajeros if p.es_mayor_de_edad()]
        return nueva

    # -----------------------------------------------------------------
    # 15. NOMBRES EN MAYÚSCULAS  (COMPRENSIÓN que TRANSFORMA)
    # -----------------------------------------------------------------
    def nombres_en_mayusculas(self):
        """
        RETORNA  : list de str ->  [p.nombre.upper() for p in self.pasajeros]
        PRUEBA   : ['DIANA', 'ANA', 'LUIS', 'BETO', 'ELENA']
        """
        # Lista 1: 4 líneas | Lista 2: 1 línea
        return [p.nombre.upper() for p in self.pasajeros]