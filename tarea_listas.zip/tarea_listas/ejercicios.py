# =====================================================================
#  ejercicios.py  —  OPCIÓN 3 DEL MENÚ: "Listar ejercicios"
# ---------------------------------------------------------------------
#  Aquí van TODOS los ejercicios del módulo 📋 Listas de la guía:
#     • 3 ejercicios DESARROLLADOS (taller paso a paso)  -> T1, T2, T3
#     • 5 ejercicios PROPUESTOS (solución oculta)         -> P1 ... P5
#
#  Cada ejercicio es UNA función sin parámetros que:
#     1) imprime su enunciado corto,
#     2) usa datos fijos de prueba (los indicados en cada función),
#     3) muestra el resultado.
#
#  REGLA: en cada ejercicio resuelve con DOS versiones cuando se indique:
#     ✋ MANUAL (bucles, patrones del módulo 0)  y  🐍 PYTHON (built-ins
#     y comprensiones). Imprime ambas para comparar.
#  Cuando termines una función, BORRA la línea "pass".
# =====================================================================


from lista_python import ListaPasajerosPython
from pasajero import Pasajero


# ============================ DESARROLLADOS ==========================

def ejercicio_t1():
    """
    T1 — CRUD de pasajeros con clase Pasajero + list   (Taller, Medio)
    -----------------------------------------------------------------
    Demuestra (sin menú, con llamadas directas) el CRUD completo usando
    tu clase ListaPasajerosPython:
        añadir 3 pasajeros -> listar -> buscar por cédula -> modificar
        -> eliminar -> listar otra vez -> ordenar por NOMBRE con
        sort(key=lambda p: p.nombre)  (es el reto del taller).
    Importa así:  from lista_python import ListaPasajerosPython
                  from pasajero import Pasajero
    """
    print("T1 — CRUD de pasajeros con clase Pasajero + list")
    lista = ListaPasajerosPython()

    # CREATE (añadir)
    lista.añadir(Pasajero("Diana", "0923456789", 22))
    lista.añadir(Pasajero("Ana",   "0912345678", 28))
    lista.añadir(Pasajero("Luis",  "0987654321", 35))
    print("\n-- Añadir 3 pasajeros y listar --")
    lista.listar()

    # READ (buscar por cédula)
    cedula = "0912345678"
    pos = lista.buscar(cedula)
    print(f"\n-- Buscar {cedula} -> posición {pos}: {lista.pasajeros[pos]}")

    # UPDATE (modificar)
    lista.modificar(cedula, "Anabel", 29)
    print("\n-- Modificar: Ana pasa a ser Anabel (29 años) --")
    lista.listar()

    # DELETE (eliminar por cédula)
    lista.eliminar_por_valor("0987654321")
    print("\n-- Eliminar a Luis y listar otra vez --")
    lista.listar()

    # RETO: ordenar por NOMBRE (antes añadimos 2 más para que se note)
    lista.añadir(Pasajero("Elena", "0901234567", 41))
    lista.añadir(Pasajero("Beto",  "0934567890", 16))
    lista.pasajeros.sort(key=lambda p: p.nombre)
    print("\n-- Ordenado por NOMBRE: sort(key=lambda p: p.nombre) --")
    lista.listar()


def ejercicio_t2():
    """
    T2 — Estadísticas de una lista de notas   (Taller, Medio)
    -----------------------------------------------------------------
    Datos:  nombres = ["Ana", "Luis", "Diana", "Beto", "Elena"]
            notas   = [ 8,     6,      10,      7,      5  ]
    Muestra: promedio, máxima, mínima, cantidad de aprobados (>= 7)
             y el nombre del mejor estudiante.
    ✋ MANUAL : un solo for con acumulador, campeón y contador.
    🐍 PYTHON : sum, max, min, len, notas.index(max(notas)) y
               aprobados con COMPRENSIÓN: [n for n in notas if n >= 7]
    Salida esperada: Promedio 7.20 · Máx 10 (Diana) · Mín 5 · Aprobados 3 de 5
    """
    print("T2 — Estadísticas de una lista de notas")
    nombres = ["Ana", "Luis", "Diana", "Beto", "Elena"]
    notas = [8, 6, 10, 7, 5]

    # ✋ MANUAL: un solo for con acumulador, campeón y contador
    suma = 0
    maxima = notas[0]
    minima = notas[0]
    pos_mejor = 0
    aprobados = 0
    for i in range(len(notas)):
        suma = suma + notas[i]                 # acumulador
        if notas[i] > maxima:                  # campeón (máximo)
            maxima = notas[i]
            pos_mejor = i
        if notas[i] < minima:                  # campeón (mínimo)
            minima = notas[i]
        if notas[i] >= 7:                      # contador
            aprobados = aprobados + 1
    promedio = suma / len(notas)
    print(f"✋ Promedio {promedio:.2f} · Máx {maxima} ({nombres[pos_mejor]}) · "
          f"Mín {minima} · Aprobados {aprobados} de {len(notas)}")

    # 🐍 PYTHON: sum, max, min, len, index y una COMPRENSIÓN para aprobados
    promedio = sum(notas) / len(notas)
    mejor = nombres[notas.index(max(notas))]
    aprobados = len([n for n in notas if n >= 7])
    print(f"🐍 Promedio {promedio:.2f} · Máx {max(notas)} ({mejor}) · "
          f"Mín {min(notas)} · Aprobados {aprobados} de {len(notas)}")


def ejercicio_t3():
    """
    T3 — Ordenar una lista (bubble sort)   (Taller, Avanzado)
    -----------------------------------------------------------------
    Datos: [5, 2, 8, 1, 9, 3, 7]
    ✋ MANUAL : burbuja con bandera hubo_swap (sobre una COPIA lista[:]).
    🐍 PYTHON : sorted(lista) y lista.sort(reverse=True).
    Extra    : palabras = ["python", "a", "código", "el"] ordenadas con key=len
    Salida esperada: [1, 2, 3, 5, 7, 8, 9]
    """
    print("T3 — Ordenar una lista (bubble sort)")
    lista = [5, 2, 8, 1, 9, 3, 7]
    print("Original:", lista)

    # ✋ MANUAL: burbuja con bandera hubo_swap, sobre una COPIA (lista[:])
    manual = lista[:]
    n = len(manual)
    for vuelta in range(n - 1):
        hubo_swap = False
        for i in range(n - 1 - vuelta):
            if manual[i] > manual[i + 1]:
                aux = manual[i]
                manual[i] = manual[i + 1]
                manual[i + 1] = aux
                hubo_swap = True
        if not hubo_swap:          # si en una vuelta no cambió nada, ya está
            break
    print("✋ Burbuja:            ", manual)

    # 🐍 PYTHON
    print("🐍 sorted(lista):      ", sorted(lista))
    desc = lista[:]
    desc.sort(reverse=True)
    print("🐍 sort(reverse=True): ", desc)

    # Extra: ordenar palabras por longitud con key=len
    palabras = ["python", "a", "código", "el"]
    print("Extra key=len:         ", sorted(palabras, key=len))


# ============================= PROPUESTOS ============================

def ejercicio_p1():
    """
    P1 — Contar apariciones de un valor
    Datos: lista = [1, 3, 2, 3, 4, 3, 5],  v = 3
    ✋ MANUAL : patrón contador.   🐍 PYTHON : lista.count(v)
    🧩 COMPRENSIÓN: len([x for x in lista if x == v])
    Salida esperada: 3 aparece 3 veces
    """
    print("P1 — Contar apariciones de un valor")
    lista = [1, 3, 2, 3, 4, 3, 5]
    v = 3

    # ✋ MANUAL: patrón contador
    contador = 0
    for i in range(len(lista)):
        if lista[i] == v:
            contador = contador + 1
    print(f"✋ {v} aparece {contador} veces")

    # 🐍 PYTHON: count()
    print(f"🐍 {v} aparece {lista.count(v)} veces")

    # 🧩 COMPRENSIÓN
    print(f"🧩 {v} aparece {len([x for x in lista if x == v])} veces")


def ejercicio_p2():
    """
    P2 — Invertir una lista SIN lista.reverse()
    Datos: [1, 2, 3, 4, 5]
    ✋ MANUAL : for con range(len(lista)-1, -1, -1) y append.
    🐍 PYTHON : lista[::-1]  y  list(reversed(lista))
    🧩 COMPRENSIÓN: [lista[i] for i in range(len(lista)-1, -1, -1)]
    Salida esperada: [5, 4, 3, 2, 1]
    """
    print("P2 — Invertir una lista SIN lista.reverse()")
    lista = [1, 2, 3, 4, 5]

    # ✋ MANUAL: recorrer de atrás hacia adelante y append
    invertida = []
    for i in range(len(lista) - 1, -1, -1):
        invertida.append(lista[i])
    print("✋", invertida)

    # 🐍 PYTHON: slicing y reversed
    print("🐍 lista[::-1]          ", lista[::-1])
    print("🐍 list(reversed(lista))", list(reversed(lista)))

    # 🧩 COMPRENSIÓN
    print("🧩", [lista[i] for i in range(len(lista) - 1, -1, -1)])


def ejercicio_p3():
    """
    P3 — Números únicos manteniendo el orden
    Datos: [1, 3, 2, 3, 4, 1, 5, 2]
    ✋ MANUAL : recorrer y añadir si "not in unicos".
    🐍 PYTHON : list(dict.fromkeys(nums))   (y explica por qué list(set(nums))
               NO garantiza el orden)
    Salida esperada: [1, 3, 2, 4, 5]
    """
    print("P3 — Números únicos manteniendo el orden")
    nums = [1, 3, 2, 3, 4, 1, 5, 2]

    # ✋ MANUAL: recorrer y añadir si "not in unicos"
    unicos = []
    for n in nums:
        if n not in unicos:
            unicos.append(n)
    print("✋", unicos)

    # 🐍 PYTHON: dict.fromkeys conserva el orden de inserción
    print("🐍", list(dict.fromkeys(nums)))
    # ¿Por qué NO list(set(nums))? Un set no tiene orden garantizado: los
    # elementos se guardan según su hash, así que el resultado puede salir
    # en cualquier orden (con enteros pequeños suele salir ordenado, pero
    # eso es casualidad y no se puede asumir).


def ejercicio_p4():
    """
    P4 — Segundo mayor (sin ordenar toda la lista)
    Datos: [5, 2, 9, 7, 9, 3, 8]
    ✋ MANUAL : dos campeones (mayor y segundo) en un solo recorrido.
    🐍 PYTHON (para comprobar): sorted(set(nums))[-2]
    Salida esperada: Mayor 9 · Segundo 8
    """
    print("P4 — Segundo mayor (sin ordenar toda la lista)")
    nums = [5, 2, 9, 7, 9, 3, 8]

    # ✋ MANUAL: dos campeones en un solo recorrido
    mayor = nums[0]
    segundo = None
    for i in range(1, len(nums)):
        n = nums[i]
        if n > mayor:                 # nuevo campeón: el anterior pasa a segundo
            segundo = mayor
            mayor = n
        elif n != mayor and (segundo is None or n > segundo):
            segundo = n               # ignora repetidos del mayor (el otro 9)
    print(f"✋ Mayor {mayor} · Segundo {segundo}")

    # 🐍 PYTHON (para comprobar)
    ordenados = sorted(set(nums))
    print(f"🐍 Mayor {ordenados[-1]} · Segundo {ordenados[-2]}")


def ejercicio_p5():
    """
    P5 — Fusionar dos listas ordenadas (sin sort)
    Datos: a = [1, 3, 5, 7],  b = [2, 4, 6, 8, 10]
    ✋ MANUAL : dos índices i, j comparando cabezas (base del merge sort)
               y al final extend con lo que sobre.
    🐍 PYTHON (para comprobar): sorted(a + b)
    Salida esperada: [1, 2, 3, 4, 5, 6, 7, 8, 10]
    """
    print("P5 — Fusionar dos listas ordenadas (sin sort)")
    a = [1, 3, 5, 7]
    b = [2, 4, 6, 8, 10]

    # ✋ MANUAL: dos índices comparando cabezas (base del merge sort)
    resultado = []
    i = 0
    j = 0
    while i < len(a) and j < len(b):
        if a[i] <= b[j]:
            resultado.append(a[i])
            i = i + 1
        else:
            resultado.append(b[j])
            j = j + 1
    resultado.extend(a[i:])        # lo que sobre de a
    resultado.extend(b[j:])        # lo que sobre de b
    print("✋", resultado)

    # 🐍 PYTHON (para comprobar)
    print("🐍", sorted(a + b))


# ============================== CATÁLOGO =============================
#  (código, título, tipo, función)   ->  tipo: "taller" o "propuesto"
#  ✅ Ya está armado: NO lo cambies, úsalo en menu_ejercicios().
EJERCICIOS = [
    ("T1", "CRUD de pasajeros con clase Pasajero + list", "taller", ejercicio_t1),
    ("T2", "Estadísticas de una lista de notas",          "taller", ejercicio_t2),
    ("T3", "Ordenar una lista (bubble sort)",             "taller", ejercicio_t3),
    ("P1", "Contar apariciones de un valor",              "propuesto", ejercicio_p1),
    ("P2", "Invertir una lista",                          "propuesto", ejercicio_p2),
    ("P3", "Números únicos",                              "propuesto", ejercicio_p3),
    ("P4", "Segundo mayor",                               "propuesto", ejercicio_p4),
    ("P5", "Fusionar dos listas ordenadas",               "propuesto", ejercicio_p5),
]


def menu_ejercicios():
    """
    QUÉ HACE : muestra los ejercicios agrupados y ejecuta el que elija
               el usuario, hasta que escriba 0.
    PASOS    :
      1. Con COMPRENSIONES separa el catálogo:
             taller     = [e for e in EJERCICIOS if e[2] == "taller"]
             propuestos = [e for e in EJERCICIOS if e[2] == "propuesto"]
      2. Muestra:
             --- DESARROLLADOS (taller) ---
               T1. CRUD de pasajeros ...
             --- PROPUESTOS ---
               P1. Contar apariciones ...
               0.  Volver
      3. Lee el código (ej. "t2") y pásalo a mayúsculas con .upper().
      4. Busca la tupla con ese código (otra comprensión o next(...)):
             encontrados = [e for e in EJERCICIOS if e[0] == codigo]
      5. Si existe -> llama a su función:  encontrados[0][3]()
         Si no     -> "Código no válido".
      6. Repite hasta que el usuario escriba "0".
    """
    while True:
        # Separo el catálogo con COMPRENSIONES
        taller = [e for e in EJERCICIOS if e[2] == "taller"]
        propuestos = [e for e in EJERCICIOS if e[2] == "propuesto"]

        print("\n--- DESARROLLADOS (taller) ---")
        for e in taller:
            print(f"  {e[0]}. {e[1]}")
        print("--- PROPUESTOS ---")
        for e in propuestos:
            print(f"  {e[0]}. {e[1]}")
        print("  0.  Volver")

        codigo = input("Código: ").strip().upper()
        if codigo == "0":
            break

        # Busco la tupla con ese código (otra COMPRENSIÓN)
        encontrados = [e for e in EJERCICIOS if e[0] == codigo]
        if encontrados:
            print()
            encontrados[0][3]()          # llamo a la función del ejercicio
        else:
            print("Código no válido")